package com.kwizzie.model;

public interface EvaluateAnswer {
	
	public void onCorrectAnswer(int time);
	public void onWrongAnswer();

}
